/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bloco;

import Transação.Transaction;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Baziota Beans
 */
public class Block 
{
    private int previousHash;
    private List<Transaction> transaction;

    public Block(int previousHash, List<Transaction> transaction) {
        this.previousHash = previousHash;
        this.transaction = transaction;
    }

    public int getPreviousHash() {
        return previousHash;
    }

    public void setPreviousHash(int previousHash) {
        this.previousHash = previousHash;
    }

    public List<Transaction> getTransaction() {
        return transaction;
    }

    public void setTransaction(List<Transaction> transaction) {
        this.transaction = transaction;
    }
    
    
}
