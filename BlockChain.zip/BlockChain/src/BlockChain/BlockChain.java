/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BlockChain;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Baziota Beans
 */
public class BlockChain 
{
    private int difficulty;
    private List<Block> blocks;
    
    
    public BlockChain(int difficulty)
    {
        this.difficulty = difficulty;
        blocks = new ArrayList<>();
        // create first Block - Genesis Block
        Block b = new Block(0, System.currentTimeMillis(), null,"First Block");
        b.mineBlock(difficulty);
        blocks.add(b);
    }
    
    public int getDifficulty()
    {
        return difficulty;
    }
    
    //retorna o último bloco do nosso blockchain
    public Block latestBlock()
    {
        return blocks.get(blocks.size() - 1);
    }
    //retorna um novo bloco
    public Block newBlock(String data)
    {
        Block latestBlock = latestBlock();
        return new Block(latestBlock.getIndex() + 1, System.currentTimeMillis(), latestBlock.getHash(), data);
    }
    //Adiciona um novo block na nossa blockchain, mas antes ele deve minerar resolvendo a famosa proof-of-work
    public void addBlock(Block b)
    {
        if(b != null)
        {
            b.mineBlock(difficulty);
            blocks.add(b);
        }
    }
    /*
        Permite verificar que o primeiro bloco do nosso blockchain é bem validado
        É Considerado validado se o seu index é igual a zero
    */
    public boolean isFirstBlockValid()
    {
        Block firstBlock = blocks.get(0);
        
        if(firstBlock.getIndex() != 0)
        {
            return false;
        }
        
        if(firstBlock.getPreviousHash() != null) return false;
        
        if(firstBlock.getHash() == null || !Block.calculateHash(firstBlock).equals(firstBlock.getHash()))
        {
            return false;
        }
        
        return true;
    }
    
    /*
        Permite validar que o novo bloco é válido comparando ao bloco anterior
    */
    public boolean isValidNewBlock(Block newBlock, Block previousBlock)
    {
        if (newBlock != null && previousBlock != null)
        {
            if(previousBlock.getIndex() + 1 != newBlock.getIndex())
            {
                return false;
            }
            
            if(newBlock.getPreviousHash() == null || !newBlock.getPreviousHash().equals(previousBlock.getHash()))
            {
                return false;
            }
            
            if(newBlock.getHash() == null || !Block.calculateHash(newBlock).equals(newBlock.getHash())) return false;
            
            return true;
        }
        return false;
    }
    /*
        Permite garantir a integridade dos dados que ela contem verificando assim a sua validação
        Para isso tudo tem de ser válido, vai ser iterado cada block validando assim a sua integridade
    */
    public boolean isBlockChainValid()
    {   
        if(!isFirstBlockValid())
        {
            return false;
        }
        for (int i = 1; i < blocks.size(); i++)
        {
            Block currentBlock = blocks.get(i);
            Block previusBlock = blocks.get(i-1);
            
            if (!isValidNewBlock(currentBlock, previusBlock)) return false;   
        }
        return true;
    }
    
    //Retorna uma representação sob forma de cadeia de caracteres dos conteudos da BlockChain
    @Override
    public String toString()
    {
        StringBuilder builder = new StringBuilder();
        
        for(Block block : blocks)
        {
            builder.append(block).append("\n");
        }
        return builder.toString();
    }
}
