/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BlockChain;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Baziota Beans
 */
public class Block 
{
    private int index;
    private long timeStamp; //Para armazenar a informação sobre a data de criação
    private String hash; // permite garantir a integridade do dado do block em curso
    private String previousHash; // permite ligar a o bloco corrente ao bloco anterior na blockchain
    private String data; //
    private int nonce; // que servirá na fase de mineração

    public Block(int index, long timeStamp, String previousHash, String data) {
        this.index = index;
        this.timeStamp = timeStamp;
        this.hash = hash;
        this.previousHash = previousHash;
        this.data = data;
        nonce = 0;
        hash = calculateHash(this);
    }

    public int getIndex() {
        return index;
    }

    public void setIndex(int index) {
        this.index = index;
    }

    public long getTimeStamp() {
        return timeStamp;
    }

    public void setTimeStamp(long timeStamp) {
        this.timeStamp = timeStamp;
    }

    public String getHash() {
        return hash;
    }

    public void setHash(String hash) {
        this.hash = hash;
    }

    public String getPreviousHash() {
        return previousHash;
    }

    public void setPreviousHash(String previousHash) {
        this.previousHash = previousHash;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }
    
    //Que envie todas as informações em forma de cadeia de caracteres do nosso block
    public String str()
    {
        return index + timeStamp + data + previousHash + nonce;
    }
    
    //Para vizualizar facilmente o conteudo de um bloco
    //Uma visualização textual do nosso bloco
    @Override
    public String toString()
    {
        StringBuilder builder = new StringBuilder();
        builder.append("Block #").append(index).append(" [previousHash: ").append(previousHash).append(", ").append("timeStamp").append(new Date(timeStamp)).append(", ").append("data: ").append(data).append(", ").append("hash: ").append(hash).append("]");
        return builder.toString();
    }
    
    /**
     * 
     * @param block
     * @return 
     * @Objectivo: mapeiar dados de entrada de tamanho arbitrario para dados de saída de tamanho fixo, culcula a hash de um dado bloco
     */
    public static String calculateHash(Block block)
    {
        if(block != null)
        {
            MessageDigest digest = null;
            try 
            {
              digest = MessageDigest.getInstance("SHA-256");
            } catch (NoSuchAlgorithmException ex) 
            {
                //Logger.getLogger(Block.class.getName()).log(Level.SEVERE, null, ex);
                return null;
            }
            String txt = block.str(); // Recuperar uma representação em forma de caracteres do nosso bloco
            final byte bytes[] = digest.digest(txt.getBytes());    //Recuperar o hash em forma de byte, construir uma cadeia de caracter em forma de tabela de bytes
            final StringBuilder builder = new StringBuilder();
            
            
            for (final byte b: bytes)
            {
                String hex = Integer.toHexString(0xff & b);
                
                if (hex.length() == 1)
                {
                    builder.append('0');
                }
                
                builder.append(hex);
            }
            return builder.toString();
        }
        
        return null;
    }
    
    //Método que nos permite minerar o bloco
    public void mineBlock(int difficulty)
    {
        nonce = 0; // a propriedade nonce armazenara o número de * antes de resolver o a prova de trabalho durante o processo de minagem do
                   // bloco corrente a dificuldade determinara o número de zero que nós teremos no principio da hash que nós queremos obter no bloco corrente
        
        while(!getHash().substring(0, difficulty).equals(Utils.zeros(difficulty)))
        {
            nonce++;
            hash = Block.calculateHash(this);
        }
    }
    
}
