/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

import Bloco.Block;
import Transação.Transaction;
import java.util.Arrays;

/**
 *
 * @author Baziota Beans
 */
public class BlockChainExample {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        /*
            BlockChain - 
            Block - Hash of previous Block + Transactions
            Chained together
        */
        
        Transaction transaction1 = new Transaction("Emma", "Beans", 100L);
        Transaction transaction2 = new Transaction("Emanuel Moura", "Rubem", 500L);
        Transaction transaction3 = new Transaction("Eidy", "Rubem", 500L);
        Transaction transaction4 = new Transaction("Edna", "Rubem", 9000L);
        /*
        System.out.println(transaction1.hashCode());
        System.out.println(transaction2.hashCode());
        System.out.println(transaction3.hashCode());
        */
        
        Block firstBlock = new Block(0, Arrays.asList(transaction1, transaction2));
        System.out.println(firstBlock.hashCode());
        Block secondBlock = new Block(firstBlock.hashCode(), Arrays.asList(transaction3));
        System.out.println(secondBlock.hashCode());
        Block thirddBlock = new Block(secondBlock.hashCode(), Arrays.asList(transaction4));
        System.out.println(thirddBlock.hashCode());
        
    }
    
}
